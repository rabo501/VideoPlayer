using VideoPlayer;
int passed=0;
void Check(bool result,string name){if(!result)throw new Exception("FAILED: "+name);Console.WriteLine("PASS "+name);passed++;}
Check(PlateOcrRules.Normalize("wx 123-45\n")=="WX12345","Normalize letters, spaces, newline, hyphen");
Check(PlateOcrRules.Normalize("O0I1B8")=="O0I1B8","No automatic O/0 I/1 B/8 substitution");
Check(PlateOcrRules.IsValidManual("wx 123-45"),"Manual lowercase and separators");
Check(!PlateOcrRules.IsValidManual(""),"Reject empty");
Check(!PlateOcrRules.IsValidManual("A"),"Reject single character");
Check(!PlateOcrRules.IsValidManual("ABCDEFGHIJKLM"),"Reject overlong number");
Check(!PlateOcrRules.IsValidManual("WX?123"),"Reject punctuation instead of silently discarding it");
Check(PlateOcrRules.Crop(1920,1080,960,600,100,130,300,180)==(200,200,400,100),"Letterbox-aware pixel coordinates");
Check(PlateOcrRules.Crop(1920,1080,960,600,300,180,100,130)==(200,200,400,100),"Reverse drag");
Check(PlateOcrRules.Crop(1920,1080,960,600,-100,-100,2000,2000)==(0,0,1920,1080),"Clamp to image bounds");
Check(PlateOcrRules.Crop(1920,1080,960,600,480,300,480,300)==(960,540,1,1),"Zero drag cannot produce invalid bitmap");


var quad=new[]{new PlatePoint(2,2),new PlatePoint(26,4),new PlatePoint(23,15),new PlatePoint(3,13)};
Check(PlatePerspective.IsValid(quad,32,24),"Perspective valid skewed quadrilateral");
var m=PlatePerspective.Transform(quad);
var uv=new[]{(0.0,0.0),(1.0,0.0),(1.0,1.0),(0.0,1.0)};
for(int i=0;i<4;i++){var p=PlatePerspective.Map(m,uv[i].Item1,uv[i].Item2);Check(Math.Abs(p.X-quad[i].X)<1e-8&&Math.Abs(p.Y-quad[i].Y)<1e-8,"Exact perspective corner "+i);}
Check(!PlatePerspective.IsValid(new[]{quad[0],quad[2],quad[1],quad[3]},32,24),"Reject crossed sides");
Check(!PlatePerspective.IsValid(new[]{new PlatePoint(-1,2),quad[1],quad[2],quad[3]},32,24),"Reject outside image");
Check(!PlatePerspective.IsValid(new[]{new PlatePoint(double.NaN,2),quad[1],quad[2],quad[3]},32,24),"Reject NaN coordinates");
Check(!PlatePerspective.IsValid(new[]{new PlatePoint(1,1),new PlatePoint(2,1),new PlatePoint(2,2),new PlatePoint(1,2)},32,24),"Reject tiny quadrilateral");
byte[] pixels=new byte[32*24*4];for(int y=0;y<24;y++)for(int x=0;x<32;x++){int k=(y*32+x)*4;pixels[k]=(byte)(x*5);pixels[k+1]=(byte)(y*7);pixels[k+2]=30;pixels[k+3]=255;}
var rectified=PlatePerspective.Rectify(pixels,32,24,quad);
Check(rectified.Width>=16&&rectified.Height>=8,"Rectified output size");
var corners=new[]{0,(rectified.Width-1)*4,(rectified.Width*rectified.Height-1)*4,(rectified.Height-1)*rectified.Width*4};
for(int i=0;i<4;i++){int a=corners[i];int b=((int)quad[i].Y*32+(int)quad[i].X)*4;Check(rectified.Pixels[a]==pixels[b]&&rectified.Pixels[a+1]==pixels[b+1],"Rectified image samples correct corner "+i);}
var identity=new[]{new PlatePoint(0,0),new PlatePoint(31,0),new PlatePoint(31,23),new PlatePoint(0,23)};
var identical=PlatePerspective.Rectify(pixels,32,24,identity);
Check(identical.Width==32&&identical.Height==24&&identical.Pixels.SequenceEqual(pixels),"Identity transform preserves every pixel");
var parallel=new[]{new PlatePoint(2,2),new PlatePoint(24,4),new PlatePoint(25,16),new PlatePoint(3,14)};
Check(PlatePerspective.IsValid(parallel,32,24),"Accept rotated parallelogram");
var affine=PlatePerspective.Transform(parallel);var center=PlatePerspective.Map(affine,.5,.5);
Check(Math.Abs(center.X-13.5)<1e-8&&Math.Abs(center.Y-9)<1e-8,"Affine special case center");


var fit=new PlateViewState(1,0,0);
var view=PlateViewport.Place(2000,1000,1000,600,fit);
Check(view==new PlateView(.5,0,50),"Fit image with letterbox");
var zoomed=PlateViewport.ZoomAt(2000,1000,1000,600,fit,2,750,300);
var after=PlateViewport.Place(2000,1000,1000,600,zoomed);
Check(Math.Abs((750-after.Left)/after.Scale-1500)<1e-8&&Math.Abs((300-after.Top)/after.Scale-500)<1e-8,"Zoom remains anchored at mouse pointer");
Check(PlateViewport.ConstrainPan(2000,1000,1000,600,2,9999,-9999)==(500.0,-200.0),"Pan cannot lose image off-screen");
Check(PlateViewport.ConstrainPan(2000,1000,1000,600,1,99,99)==(0.0,0.0),"Fit mode centers image");
Check(PlateViewport.ZoomAt(2000,1000,1000,600,zoomed,.1,500,300)==fit,"Zoom out to fit clears panning");
Check(PlateViewport.ZoomAt(2000,1000,1000,600,fit,1000,500,300).Zoom==16,"Zoom maximum clamped");
var sameZoom=PlateViewport.ZoomAt(2000,1000,1000,600,zoomed,2,333,222);
Check(Math.Abs(sameZoom.PanX-zoomed.PanX)<1e-8&&Math.Abs(sameZoom.PanY-zoomed.PanY)<1e-8,"Same zoom does not move image");
var point=new PlatePoint(1200,450);
double sx=after.Left+point.X*after.Scale,sy=after.Top+point.Y*after.Scale;
Check(Math.Abs((sx-after.Left)/after.Scale-point.X)<1e-8&&Math.Abs((sy-after.Top)/after.Scale-point.Y)<1e-8,"Selection coordinate round trip under zoom and pan");
var resized=PlateViewport.Place(2000,1000,800,450,zoomed);
double rx=resized.Left+point.X*resized.Scale,ry=resized.Top+point.Y*resized.Scale;
Check(Math.Abs((rx-resized.Left)/resized.Scale-point.X)<1e-8&&Math.Abs((ry-resized.Top)/resized.Scale-point.Y)<1e-8,"Selection coordinate round trip after viewport resize");
Console.WriteLine($"{passed} tests passed.");
