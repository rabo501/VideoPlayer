# VideoPlayer 1.2 — układ do analizy nagrań

## Rozmieszczenie
- Podgląd zajmuje lewą i największą część okna. Nie znajduje się w przewijanej stronie.
- Oś czasu i sterowanie odtwarzaniem są w stałych dolnych rzędach na całą szerokość okna. Nie znikają przy przewijaniu panelu ani zmianie zakładki.
- Prawy panel ma zakładki Fragmenty, Zdarzenia, Eksport i Pliki. Przewijanie dotyczy wyłącznie zawartości zakładki; listy mają własne przewijanie.
- Przeciągnięcie separatora zmienia szerokość panelu. Przycisk na górze i menu Widok pozwalają go ukryć lub pokazać. Po ukryciu podgląd otrzymuje zwolnione miejsce, bez usuwania osi czasu.
- Status, postęp operacji oraz Anuluj są zawsze na dole, niezależnie od zakładki.

## Fragmenty
Zatrzymaj film, ustaw Początek (I), przejdź dalej, ustaw Koniec (O), nazwij fragment i kliknij Dodaj zaznaczenie. Przy liście widać czasy i liczbę fragmentów. Wczytuj, aktualizuj i usuwaj pozycje z listy. Przycisk Przejdź do eksportu otwiera odpowiednią zakładkę.

## Zdarzenia
Opis i dodawanie znacznika, lista zdarzeń oraz raporty CSV/PDF. Dwuklik na pozycji przenosi do czasu zdarzenia. Opcja miniatur dotyczy PDF.

## Eksport
Profil jakości, kopiowanie strumieni, eksport aktualnego zaznaczenia, eksport całej listy i utworzenie nowego filmu bez zaznaczenia. Zaznaczenie i profil są wspólne dla zakładek; zmiana zakładki nie resetuje danych. Oryginał pozostaje bez zmian.

## Pliki
Historia nagrań i zapisanych klatek. Informacje o nagraniu oraz ustawienia widoku i sesji są w rozwijanych sekcjach. Przywracanie sesji pozostaje włączone domyślnie.

## Menu i skróty
Plik: otwieranie, zapis sesji, zamknięcie. Widok: panel narzędzi, dopasowanie, wypełnienie, powiększenia i reset. Pomoc: nowa instrukcja, restart mpv i informacje o wersji.
Spacja: Play/pauza. Strzałki: klatki. I/O: zakres. S: klatka JPG. Ctrl+O: otwórz. R: reset widoku. Kółko i przeciąganie zachowano z 1.1.1.
Prawy przycisk na filmie otwiera menu początku, końca, zapisu klatki, resetu i przejścia do opisu zdarzenia. Po wybraniu Dodaj zdarzenie… trzeba wpisać opis i zatwierdzić dodawanie w zakładce Zdarzenia; samo otwarcie pola nie zapisuje znacznika.

## Instalacja do testów
1. Zamknij poprzednią aplikację. Zachowaj kopię projektu i bazy VideoPlayer.db, wraz z ewentualnymi plikami -wal/-shm.
2. Rozpakuj ten PEŁNY projekt do nowego katalogu. Nie nakładaj go na jedyną kopię własnych zmian.
3. Dodaj dotychczasowe kompletne katalogi mpv i ffmpeg obok VideoPlayer.csproj, razem z wymaganymi DLL. Paczka nie zawiera silników natywnych ani bazy.
4. Otwórz VideoPlayer/VideoPlayer.csproj w Visual Studio z obsługą WPF/.NET 8, przywróć NuGet i przebuduj projekt. Alternatywa: dotnet build VideoPlayer/VideoPlayer.csproj -c Release.
5. Uruchom nowy wynik w bin/Release/net8.0-windows. Muszą być tam też katalogi mpv, ffmpeg i scripts. Sprawdź wersję 1.2.0 w Pomoc → Informacje.
6. Opcjonalnie przenieś KOPIĘ dotychczasowej bazy do katalogu nowego EXE przy zamkniętej aplikacji. Aktualizacja interfejsu nie zmienia schematu sesji ani list fragmentów.

## Lista testów Windows
- Zmieniaj rozmiar okna, przechodź przez cztery zakładki i przewijaj listy. Oś czasu i odtwarzanie mają pozostać widoczne.
- Zwęź, rozszerz, ukryj i pokaż panel. Sprawdź podgląd oraz klikanie osi i znaczników po zmianie szerokości.
- Sprawdź Play/pauzę, klatki, prędkość, zoom, przesuwanie, reset i menu pod prawym przyciskiem na obrazie.
- Dodaj, zaktualizuj i wczytaj dwa fragmenty. Przełącz zakładki i upewnij się, że zaznaczenie oraz lista pozostają.
- Wyeksportuj fragmenty. Przełącz zakładkę podczas eksportu: postęp i Anuluj mają pozostać dostępne.
- Dodaj znaczniki i sprawdź raporty CSV/PDF oraz otwieranie z historii i zapisane klatki.
- Zamknij i otwórz ten sam film, sprawdź przywrócenie sesji.

## Zakres sprawdzenia
Kompilacja całego WPF: 0 błędów, 0 ostrzeżeń. Przeszło 19 testów .NET/FFmpeg, 9 testów skryptu Lua z makietą API i kontrole struktury XAML, których wyniki są w Weryfikacja.
Nie uruchomiono interfejsu w Windows ani prawdziwego osadzonego mpv. Kontrole struktury nie są testami wyglądu, DPI ani zdarzeń w działającym oknie. Szczególnie menu kontekstowe, separator i skróty przy fokusie na obrazie wymagają Twojego testu.

Założenia: bazą była wersja 1.1.1. Zmieniono układ bez usuwania funkcji. Rozmiar panelu i wybór zakładki nie są zapamiętywane między uruchomieniami. Minimalny rozmiar okna to 900 × 600 jednostek WPF; rozmiar początkowy 1280 × 780.
