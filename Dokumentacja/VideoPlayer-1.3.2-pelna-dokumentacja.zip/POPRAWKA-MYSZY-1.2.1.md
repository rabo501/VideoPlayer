# VideoPlayer 1.2.1 — przesuwanie i powiększanie

## Co zmieniono
Odbiór myszy jest teraz realizowany po stronie aplikacji Windows przez WM_INPUT (Raw Input), a nie przez obserwowanie mouse-pos w skrypcie mpv. Ruch i kółko trafiają przez IPC do jednej funkcji vp-pointer. Usunięto poprzednie powiązania kółka/lewego przycisku w Lua, aby uniknąć podwójnego zoomu.

Gesty są używane tylko gdy aplikacja jest na pierwszym planie, kursor jest nad widocznym oknem podglądu i nie trwa otwieranie/zamykanie filmu. Nie blokują myszy w innych aplikacjach. Polecenia są agregowane przed wysłaniem, zamiast wysyłać osobne żądanie IPC dla każdego zdarzenia sprzętowego. Nie użyto globalnych haków myszy.

## Sterowanie
- Kółko w górę: powiększanie wokół kursora; w dół: pomniejszanie. Maksymalnie 16×.
- Przy powiększonym obrazie: przytrzymaj LEWY przycisk nad filmem i przeciągnij. Kadr podąża za ruchem w obu osiach.
- Zwolnienie przycisku, wyjście poza podgląd lub przełączenie aplikacji kończy przeciąganie. Aby zacząć ponownie, puść przycisk i naciśnij go nad obrazem.
- R lub Widok → Resetuj widok przywraca cały kadr i zeruje przesunięcie. Zejście kółkiem do dopasowania również centruje obraz (poza trybem wypełnienia).
- Prawy przycisk zachowuje menu kontekstowe. Układ zakładek i osi czasu nie został zmieniony.

## Instalacja
1. Zamknij starą wersję. Zrób kopię projektu i VideoPlayer.db; jeżeli istnieją pliki -wal/-shm, zachowaj je razem z bazą po zamknięciu programu.
2. Rozpakuj pełny projekt do nowego katalogu. Dodaj swoje kompletne foldery mpv i ffmpeg obok VideoPlayer.csproj. Silników natywnych ani bazy nie ma w tej paczce.
3. Otwórz VideoPlayer/VideoPlayer.csproj w Visual Studio i wykonaj Przebuduj rozwiązanie. W razie używania dotnet: dotnet build VideoPlayer/VideoPlayer.csproj -c Release.
4. Uruchom EXE z nowego katalogu wynikowego, nie starą kopię. Obok niego muszą być mpv, ffmpeg i zaktualizowany scripts/review.lua. Pomoc → Informacje ma pokazywać 1.2.1.
5. Jeśli potrzebujesz starej sesji, skopiuj kopię bazy do katalogu nowego EXE przy zamkniętej aplikacji.

Nie wystarczy podmienić sam review.lua: poprawka wymaga też nowych plików C# i przebudowania EXE. Wersja 1.2.1 musi być uruchamiana z kompletem swoich plików.

## Szybki test Windows
Otwórz film i zatrzymaj go. Ustaw kursor w narożniku obrazu i obróć kółko. Wybrany szczegół powinien pozostawać przy kursorze. Przy powiększeniu przeciągnij lewym przyciskiem w poziomie i pionie. Powtórz po użyciu powiększenia z menu, zmianie rozmiaru okna, schowaniu panelu i wznowieniu filmu. Naciśnij R i sprawdź powrót całego kadru. Nad listą fragmentów kółko ma nadal przewijać listę, a nie zmieniać zoom.

## Weryfikacja i ograniczenia
Kompilacja całego projektu: bez błędów i ostrzeżeń. Przeszło 16 testów logiki Lua (zoom, przesunięcie, utrzymanie punktu pod kursorem, limity, geometria zastępcza i brak podwójnych powiązań) oraz 19 dotychczasowych testów .NET/FFmpeg. Wyniki są w Weryfikacja.
Nie uruchomiono natywnego WM_INPUT, interfejsu WPF ani rzeczywistego mpv w Windows. Testy Lua używają makiety API mpv; nie potwierdzają odbioru gestów z Twojej myszy ani zachowania zdalnego pulpitu. To pozostaje do sprawdzenia na Windows. Błąd rejestracji wejścia jest pokazywany w dolnym statusie zamiast ignorowania.

Założenie: poprawka oparta na pełnej wersji 1.2, bez zmian schematu bazy i bez zmian interfejsu.

Dokumentacja mechanizmu: https://learn.microsoft.com/en-us/windows/win32/inputdev/about-raw-input oraz https://mpv.io/manual/stable/ (video-pan-x/video-pan-y, osd-dimensions).
