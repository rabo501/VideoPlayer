# VideoPlayer 1.3.1 — cztery narożniki i prostowanie

Przed aktualizacją zachowaj kopię działającego projektu i bazy. Rozpakuj paczkę do nowego folderu. Do katalogu VideoPlayer skopiuj dotychczasowe mpv i ffmpeg. Projekt nadal wymaga .NET 8 Desktop i x64. OCR i model pozostają dołączone, bez nowych pakietów NuGet.

## Obsługa
1. Otwórz Zdarzenia → Rozpoznaj tablicę — lokalnie.
2. Przeciągnij myszą po obszarze tablicy, jak dotychczas.
3. Przesuwaj białe kółka: 1 lewy górny, 2 prawy górny, 3 prawy dolny, 4 lewy dolny. Dopasuj obszar samych znaków z małym marginesem, bez paska PL i obramowania. Kolejność narożników nie zmienia się podczas przeciągania.
4. Po puszczeniu myszy zobaczysz wyprostowany wycinek. Ten wycinek trafia do istniejącego przygotowania obrazu i silnika OCR. Podgląd jest przed filtrami kontrastu/progowania, nie przedstawia ich wyników.
5. Czerwona ramka oznacza nieprawidłowy, zbyt mały lub skrzyżowany obszar — popraw narożniki. Nowe zaznaczenie usuwa wcześniejsze punkty.
6. Kliknij Rozpoznaj, popraw numer i potwierdź zapis. Zmiana zaznaczenia kasuje poprzednie propozycje i potwierdzenie, żeby nie zapisać starego wyniku.

Zmiana rozmiaru okna zachowuje punkty w oryginalnych pikselach filmu. Ramka OCR nie zmienia zoomu i przesuwania w głównym odtwarzaczu. Oryginalny film jest niezmieniony. Najnowszy ReportService.cs i dotychczasowa baza bez zmian.

## Ograniczenia
Korekta perspektywy nie gwarantuje poprawnego odczytu ani nie odzyskuje niewidocznych szczegółów. Odczyty sprawdzaj ręcznie. Wyjściowe wymiary wynikają z długości boków zaznaczenia, a nie z założenia jednego rodzaju tablicy. Mocny skrót perspektywiczny może nadal pogarszać wynik. Podgląd aktualizowany jest po puszczeniu myszy, nie podczas każdej klatki przeciągania.

## Technicznie
Korekta projekcyjna z czterech punktów, próbkowanie biliniowe, bez nowych bibliotek natywnych. Obraz wyjściowy jest ograniczony rozmiarem, aby nie tworzyć nieograniczonych alokacji.
Opis transformacji perspektywicznej: https://docs.opencv.org/3.4.0/da/d54/group__imgproc__transform.html (projekt używa własnej implementacji C#, nie zależności OpenCV).

Testy reguł i geometrii: dotnet run --project Tests.Ocr/Tests.Ocr.csproj
Interfejs WPF, mysz oraz natywny OCR należy sprawdzić na Windows. Testy algorytmu nie zastępują testów rozpoznawania rzeczywistych tablic.
