# Testy silnika eksportu

Testy kompilują rzeczywiste pliki usług z projektu, nie ich makiety. Nie uruchamiają WPF, mpv ani PDF.

Wymagane: .NET 8 i FFmpeg z libx264, AAC i lavfi w VideoPlayer/ffmpeg.
Z głównego katalogu paczki, w PowerShell, wykonaj kolejno:

    powershell -ExecutionPolicy Bypass -File .\Tests\Prepare-TestData.ps1
    dotnet run --project .\Tests\Tests.csproj -- .\Tests\Work

Skrypt tworzy dwa syntetyczne nagrania w Tests/Work. Przy ponownym uruchomieniu usuwa tylko pliki testów o ustalonych nazwach z tego katalogu. Nie zapisuj tam własnych plików.

Oczekiwany wynik: TOTAL PASS: 19. Test anulowania może być niejednoznaczny na wyjątkowo szybkim komputerze, jeśli kodowanie zakończy się przed anulowaniem; wówczas wypisuje stosowny komunikat.

Zakres: rozpoznanie audio i jego braku, dokładny eksport, usunięcie środka z audio, początku bez audio i końca, kopiowanie strumieni, miniatura, ochrona źródła, ochrona istniejącego wyniku, odwrócony zakres, aktywne anulowanie i sprzątanie, niezmienność SHA-256 źródła.

Dodatkowo sześć testów walidacji zakresu. Test-review-lua.lua zawiera osiem testów skryptu z makietą API mpv. Z katalogu Tests: lua Test-review-lua.lua ../VideoPlayer/scripts/review.lua. Wymagany interpreter Lua. Nie jest to test rzeczywistego mpv.
