﻿$ErrorActionPreference = 'Stop'
$work = Join-Path $PSScriptRoot 'Work'
$native = Join-Path (Split-Path $PSScriptRoot -Parent) 'VideoPlayer\ffmpeg'
$exe = Join-Path $native 'ffmpeg.exe'
if (-not (Test-Path -LiteralPath $exe)) { throw 'Brak VideoPlayer\ffmpeg\ffmpeg.exe.' }
New-Item -ItemType Directory -Force -Path $work | Out-Null
$targetNative = Join-Path $work 'ffmpeg'
New-Item -ItemType Directory -Force -Path $targetNative | Out-Null
Copy-Item -Path (Join-Path $native '*') -Destination $targetNative -Recurse -Force
foreach ($name in @('audio.mp4','silent.mp4','clip.mp4','removed.mp4','removed_silent.mp4','removed_end.mp4','copy.mp4','frame.jpg','cancelled.mp4','invalid.mp4')) {
  $path = Join-Path $work $name
  if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force }
}
$ffmpeg = Join-Path $targetNative 'ffmpeg.exe'
& $ffmpeg -hide_banner -loglevel error -y -f lavfi -i 'testsrc2=size=320x240:rate=25' -f lavfi -i 'sine=frequency=440:sample_rate=48000' -t 4 -c:v libx264 -threads 1 -preset ultrafast -pix_fmt yuv420p -c:a aac (Join-Path $work 'audio.mp4')
if ($LASTEXITCODE -ne 0) { throw 'Nie utworzono nagrania z audio.' }
& $ffmpeg -hide_banner -loglevel error -y -f lavfi -i 'testsrc2=size=320x240:rate=25' -t 4 -c:v libx264 -threads 1 -preset ultrafast -pix_fmt yuv420p (Join-Path $work 'silent.mp4')
if ($LASTEXITCODE -ne 0) { throw 'Nie utworzono nagrania bez audio.' }
Write-Host 'Gotowe. Uruchom: dotnet run --project .\Tests\Tests.csproj -- .\Tests\Work'
