local messages,bindings,props,parameters={},{},{},{}
local no_osd=false
local mp={}
function mp.get_property_number(k,d)return props[k] or d end
function mp.set_property_number(k,v)assert(v==v and v~=math.huge and v~=-math.huge);props[k]=v end
function mp.get_property_native(k)
 if k=='osd-dimensions' and not no_osd then
  local w,h=1000,500;local scale=2^(props['video-zoom'] or 0)
  return {w=w,h=h,ml=(w-w*scale)/2,mr=(w-w*scale)/2,mt=(h-h*scale)/2,mb=(h-h*scale)/2}
 end
 if k=='video-out-params' then return parameters end
end
function mp.register_script_message(k,f)messages[k]=f end
function mp.add_forced_key_binding(k,n,f)bindings[k]=f end
function mp.commandv(...)end
package.preload['mp']=function()return mp end
dofile(arg[1])
local count=0
local function check(name,fn)
 props={};parameters={dw=1920,dh=1080};no_osd=false
 fn();count=count+1;print('PASS '..name)
end
local function eq(a,b)assert(math.abs(a-b)<0.000001,tostring(a)..' != '..tostring(b))end
local function move(dx,dy,wheel,x,y,w,h)
 messages['vp-pointer'](tostring(dx),tostring(dy),tostring(wheel),tostring(x or .5),tostring(y or .5),tostring(w or 1000),tostring(h or 500))
end
check('wheel zoom in',function()move(0,0,1);eq(props['video-zoom'],.2);eq(props['video-pan-x'],0)end)
check('off-center cursor stays on same image point',function()
 props['video-zoom']=1;props['video-pan-x']=.1
 local old_image_x=(750-500-.1*2000)/2000
 move(0,0,1,.75,.5)
 local new_width=1000*2^props['video-zoom']
 local new_image_x=(750-500-props['video-pan-x']*new_width)/new_width
 eq(old_image_x,new_image_x)
end)
check('drag horizontally at 2x zoom',function()props['video-zoom']=1;move(.1,0,0);eq(props['video-pan-x'],.05)end)
check('drag left and up',function()props['video-zoom']=1;move(-.2,-.1,0);eq(props['video-pan-x'],-.1);eq(props['video-pan-y'],-.05)end)
check('zoom out restores fit and centered view',function()props['video-zoom']=.2;props['video-pan-x']=.3;props['video-pan-y']=-.1;move(0,0,-1);eq(props['video-zoom'],0);eq(props['video-pan-x'],0);eq(props['video-pan-y'],0)end)
check('upper zoom limit',function()props['video-zoom']=4;move(0,0,20);eq(props['video-zoom'],4)end)
check('lower zoom limit',function()move(0,0,-5);eq(props['video-zoom'],0)end)
check('high resolution wheel partial notch',function()move(0,0,.25);eq(props['video-zoom'],.05)end)
check('fallback without OSD metadata permits pan',function()no_osd=true;props['video-zoom']=1;move(.1,0,0);eq(props['video-pan-x'],.05625)end)
check('rotated video fallback',function()no_osd=true;parameters.rotate=90;props['video-zoom']=1;move(.1,0,0);assert(props['video-pan-x']>0)end)
check('zoom without any video geometry',function()no_osd=true;parameters=nil;move(0,0,1);eq(props['video-zoom'],.2)end)
check('invalid data ignored',function()messages['vp-pointer']('bad','0','1','.5','.5','1000','500');assert(props['video-zoom']==nil)end)
check('zero viewport ignored',function()move(.1,0,1,.5,.5,0,500);assert(props['video-zoom']==nil)end)
check('no duplicate native wheel and left-button bindings',function()assert(not bindings.WHEEL_UP and not bindings.WHEEL_DOWN and not bindings.MBTN_LEFT)end)
check('right click still opens context menu',function()local command;mp.commandv=function(...)command={...}end;bindings.MBTN_RIGHT();assert(command[1]=='script-message' and command[2]=='vp-action' and command[3]=='context')end)
check('pan limit remains finite',function()props['video-zoom']=1;move(1000,-1000,0);eq(props['video-pan-x'],4);eq(props['video-pan-y'],-4)end)
print('TOTAL LUA PASS: '..count)
