
using VideoPlayer;
using System.Security.Cryptography;
string root=args[0];var service=new ExportService(new FfmpegService(root));
var progress=new Progress<ExportProgress>(_=>{});int passed=0;
async Task Check(string name,Func<Task> test){await test();Console.WriteLine("PASS "+name);passed++;}
string Audio=Path.Combine(root,"audio.mp4"),Silent=Path.Combine(root,"silent.mp4");
string Out(string name)=>Path.Combine(root,name);
string hash=Convert.ToHexString(SHA256.HashData(await File.ReadAllBytesAsync(Audio)));
async Task Length(string file,double expected){var info=await service.ProbeAsync(file,default);if(Math.Abs(info.Duration-expected)>.18)throw new Exception($"{file}: duration {info.Duration}, expected {expected}");}
await Check("Probe audio",async()=>{var i=await service.ProbeAsync(Audio,default);if(!i.HasAudio||Math.Abs(i.Duration-4)>.1)throw new Exception("Probe");});
await Check("Probe without audio",async()=>{var i=await service.ProbeAsync(Silent,default);if(i.HasAudio)throw new Exception("Audio detected");});
await Check("Accurate export",async()=>{await service.ExportAsync(Audio,Out("clip.mp4"),.5,2.5,"standard",false,progress,default);await Length(Out("clip.mp4"),2);});
await Check("Remove middle with audio",async()=>{await service.RemoveAsync(Audio,Out("removed.mp4"),1,2,4,true,progress,default);await Length(Out("removed.mp4"),3);});
await Check("Remove beginning without audio",async()=>{await service.RemoveAsync(Silent,Out("removed_silent.mp4"),0,1,4,false,progress,default);await Length(Out("removed_silent.mp4"),3);});
await Check("Remove end",async()=>{await service.RemoveAsync(Audio,Out("removed_end.mp4"),2,4,4,true,progress,default);await Length(Out("removed_end.mp4"),2);});
await Check("Stream copy",async()=>{await service.ExportAsync(Audio,Out("copy.mp4"),0,2,"standard",true,progress,default);if(new FileInfo(Out("copy.mp4")).Length==0)throw new Exception("Empty");});
await Check("Thumbnail",async()=>{await service.ThumbnailAsync(Audio,1,Out("frame.jpg"),default);if(new FileInfo(Out("frame.jpg")).Length==0)throw new Exception("Empty image");});
await Check("Do not overwrite source",async()=>{try{await service.ExportAsync(Audio,Audio,0,1,"standard",false,progress,default);}catch(IOException){return;}throw new Exception("Source overwritten");});
await Check("Do not overwrite existing output",async()=>{try{await service.ExportAsync(Audio,Out("clip.mp4"),0,1,"standard",false,progress,default);}catch(IOException){return;}throw new Exception("Output overwritten");});
await Check("Reject reversed range",async()=>{try{await service.ExportAsync(Audio,Out("invalid.mp4"),2,1,"standard",false,progress,default);}catch(ArgumentException){return;}throw new Exception("Range accepted");});
await Check("Active cancellation and cleanup",async()=>{
 using var cts=new CancellationTokenSource(TimeSpan.FromMilliseconds(80));
 try{await service.ExportAsync(Audio,Out("cancelled.mp4"),0,4,"quality",false,progress,cts.Token);}catch(OperationCanceledException){if(File.Exists(Out("cancelled.mp4")))throw new Exception("Partial final file");if(Directory.GetFiles(root,".vp_*").Length!=0)throw new Exception("Temporary file remains");return;}
 throw new Exception("Encoding finished before cancellation; test inconclusive");});
await Check("Source SHA256 unchanged",async()=>{if(hash!=Convert.ToHexString(SHA256.HashData(await File.ReadAllBytesAsync(Audio))))throw new Exception("Source modified");});
await Check("Range: valid",()=>{if(ClipRangeValidator.Error(1,2,4)!=null)throw new Exception("Rejected valid range");return Task.CompletedTask;});
await Check("Range: missing start",()=>{if(ClipRangeValidator.Error(null,2,4)==null)throw new Exception("Accepted");return Task.CompletedTask;});
await Check("Range: missing end",()=>{if(ClipRangeValidator.Error(1,null,4)==null)throw new Exception("Accepted");return Task.CompletedTask;});
await Check("Range: reversed",()=>{if(ClipRangeValidator.Error(2,1,4)==null)throw new Exception("Accepted");return Task.CompletedTask;});
await Check("Range: nonfinite",()=>{if(ClipRangeValidator.Error(double.NaN,2,4)==null)throw new Exception("Accepted");return Task.CompletedTask;});
await Check("Range: outside movie",()=>{if(ClipRangeValidator.Error(1,5,4)==null)throw new Exception("Accepted");return Task.CompletedTask;});
Console.WriteLine($"TOTAL PASS: {passed}");
