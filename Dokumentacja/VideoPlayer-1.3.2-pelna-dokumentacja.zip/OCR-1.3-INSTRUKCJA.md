# VideoPlayer 1.3 — lokalny odczyt tablic

## Uruchomienie i kopia bezpieczeństwa
Zachowaj działającą wersję 1.2.1 oraz kopię bazy danych. Rozpakuj tę wersję do NOWEGO katalogu. Do VideoPlayer skopiuj dotychczasowe katalogi mpv i ffmpeg. Otwórz projekt w Visual Studio i zbuduj x64 (.NET 8 Desktop). Nie zmieniono schematu bazy danych.

Dołączono Tesseract .NET 5.2.0, natywne biblioteki x64 i model eng.traineddata (tessdata_fast). Nie trzeba instalować Tesseract ani Pythona. OCR nie pobiera niczego podczas działania. Budowanie projektu nadal może wymagać standardowego przywrócenia dotychczasowych zależności SQLite/PDFsharp z NuGet. System musi mieć Microsoft Visual C++ Redistributable 2015–2022 x64 (na komputerze offline można zainstalować wcześniej przeniesiony instalator Microsoft).

## Obsługa
1. Otwórz film i zatrzymaj interesującą klatkę (przycisk OCR sam też włącza pauzę).
2. W zakładce Zdarzenia kliknij „Rozpoznaj tablicę — lokalnie”.
3. W osobnym oknie zaznacz myszą SAME znaki tablicy z małym marginesem; pomiń pasek PL. Widok pokazuje pełną klatkę, a nie powiększenie odtwarzacza. Zoom i przesuwanie w głównym oknie pozostają bez zmian.
4. Kliknij „Rozpoznaj zaznaczoną tablicę”. Program testuje skalowanie, odcienie szarości i dwa warianty progowania. Można wybrać inne propozycje albo wpisać poprawny numer ręcznie.
5. Sprawdź O/0, I/1, B/8. Zaznacz potwierdzenie poprawności i kliknij „Zapisz jako zdarzenie”. Nigdy nie zapisuj numeru, którego nie da się zweryfikować na obrazie.
6. Zdarzenie trafia do istniejącej listy i raportów PDF/CSV. Raport PDF ze zdjęciami generuje standardową miniaturę pełnej klatki przy zapisanym czasie. Nie dodano osobnej bazy tablic ani zapisywania wyciętej tablicy.

## Prywatność i ograniczenia
Przetwarzanie wyłącznie lokalne. Tymczasowa klatka PNG jest usuwana przy zamknięciu okna OCR (po awarii procesu może pozostać w systemowym katalogu tymczasowym VideoPlayer_OCR_*). Odczyt nie wysyła zapytań do internetu ani nie sprawdza rejestrów pojazdów. Oryginalny film pozostaje niezmieniony. Obsługiwane znaki: A–Z oraz 0–9; spacje i łączniki w ręcznie poprawionym numerze są pomijane. To OCR zaznaczonej tablicy, nie automatyczny detektor samochodów, nie analiza całego filmu. Rozmytych, zasłoniętych lub bardzo małych znaków nie da się wiarygodnie odtworzyć.

Zachowano najnowszy ReportService.cs: pełna nazwa autora zamiast loginu i wspólny styl stopki Arial 8. Uwaga: dotychczasowe raporty nadal zawierają pełną ścieżkę źródłowego filmu — ścieżka może zawierać nazwę konta Windows.

## Kontrola po uruchomieniu na Windows
- Odczyt czytelnej tablicy po odłączeniu internetu.
- Zaznaczenie w obie strony, zmiana rozmiaru okna, nowy obszar i ponowny odczyt.
- Poprawienie wyniku, brak możliwości zapisu bez potwierdzenia, anulowanie w trakcie odczytu.
- Zgodność czasu zdarzenia z klatką, ponowne otwarcie filmu, eksport PDF/CSV.
- Kontrola zoomu/przesuwania/R oraz nowej stopki PDF.

## Źródła i licencje
Wrapper: https://github.com/charlesw/tesseract (Apache 2.0).
Model: https://github.com/tesseract-ocr/tessdata_fast (Apache 2.0, licencja w tessdata/LICENSE).
Silnik: https://github.com/tesseract-ocr/tesseract (Apache 2.0).
Leptonica: https://github.com/DanBloomberg/leptonica (licencja BSD; pliki w licenses).

## Testy automatyczne
dotnet run --project Tests.Ocr/Tests.Ocr.csproj sprawdza wspólne reguły numeru i przeliczanie współrzędnych zaznaczenia (również pasy, odwrotny kierunek i granice obrazu). Nie zastępuje testów interfejsu WPF i natywnych bibliotek na Windows.
