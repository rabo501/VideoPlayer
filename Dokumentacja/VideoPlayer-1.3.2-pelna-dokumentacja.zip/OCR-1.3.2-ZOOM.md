# VideoPlayer 1.3.2 — powiększanie klatki przed zaznaczeniem

Zrób kopię projektu i bazy. Rozpakuj do nowego katalogu, skopiuj swoje mpv i ffmpeg do VideoPlayer i zbuduj projekt x64 (.NET 8 Desktop). Silnik i model OCR są w paczce.

## Sterowanie w oknie OCR
- Kółko myszy: powiększaj i pomniejszaj klatkę pod kursorem, również przed pierwszym zaznaczeniem.
- Prawy przycisk myszy i przeciąganie: przesuń powiększoną klatkę.
- Lewy przycisk myszy: zaznacz obszar albo przesuń jeden z czterech narożników.
- Przyciski + i −: zmień powiększenie względem środka widoku.
- Dopasuj: wróć do całej klatki bez usuwania zaznaczenia.

Zakres powiększenia: od dopasowania całej klatki do 16-krotnego powiększenia tego dopasowania; to nie skala natywnych pikseli filmu. Przesuwanie jest ograniczone tak, żeby obraz nie znikał poza widokiem. Podczas przeciągania narożnika zoom jest blokowany — puść przycisk przed kolejną zmianą widoku.

Narożniki są przechowywane w oryginalnych współrzędnych filmu. Zoom, przesunięcie i zmiana rozmiaru okna nie zmieniają wycinka OCR ani poprzedniego wyniku. Przesunięcie narożnika lub nowe zaznaczenie wymaga ponownego rozpoznania. Podgląd wyprostowanego obrazu aktualizuje się po puszczeniu narożnika.

Powiększenie pomaga precyzyjnie ustawić ramkę, ale nie dodaje szczegółów do oryginalnej klatki i nie gwarantuje poprawnego odczytu. Wynik nadal sprawdzaj ręcznie.

Główny odtwarzacz, baza, eksporty i najnowszy ReportService.cs pozostają bez zmian.
Testy: dotnet run --project Tests.Ocr/Tests.Ocr.csproj
Interfejs WPF i działanie myszy należy sprawdzić na Windows.
