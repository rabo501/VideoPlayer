# VideoPlayer 1.3.2 — dokumentacja

Pełna instrukcja wszystkich funkcji i uruchomienia: DOKUMENTACJA-1.3.2.md.
Wersja do wydruku: dokumentacja/Dokumentacja-VideoPlayer-1.3.2.pdf.
Wersja edytowalna: dokumentacja/Dokumentacja-VideoPlayer-1.3.2.docx.

Zacznij od kopii projektu i bazy VideoPlayer.db. Paczka zawiera źródła, nie instalator. Skopiuj własne katalogi mpv i ffmpeg i buduj projekt x64 dla Windows. Starsze instrukcje cząstkowe są historyczne; aktualny opis znajduje się w pełnej dokumentacji.
